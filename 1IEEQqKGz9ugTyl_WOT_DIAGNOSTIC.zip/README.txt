WOT Secure-PAC diagnostic sample
Contains limited samples and metadata only, not the full firmware.
This archive cannot be flashed. Do not rename samples to .pac.
